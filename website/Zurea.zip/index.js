var sidenav = document.querySelector(".side-avbar")

function showNavbar()
{
sidenav.style.left="0"
}

function closeNavbar()
{
sidenav.style.left="-60%"
}